This is the grocery app for the final project of smartinternz google virtual internship.
