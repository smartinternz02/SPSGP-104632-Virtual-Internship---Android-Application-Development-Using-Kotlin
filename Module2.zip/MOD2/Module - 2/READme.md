It includes all the apps covered in Module - 2 "Layout"
