This folders includes all the applications made during the completion of Module 4 - "Connect to the Internet"
